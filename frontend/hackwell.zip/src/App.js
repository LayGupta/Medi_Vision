import React, { useState, useEffect } from "react";
import { fetchPatients, fetchPatient } from "./services/api";
import CohortView from "./components/CohortView";
import PatientDetail from "./components/PatientDetail";
import "./App.css";

export default function App() {
  const [patients, setPatients] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null);

  useEffect(() => {
    async function load() {
      const data = await fetchPatients();
      setPatients(data);
    }
    load();
  }, []);

  const handleSelect = async (id) => {
    const data = await fetchPatient(id);
    setSelectedPatient(data);
  };

  return (
    <div className="app-container">
      <h1 className="app-title">AI-Driven Risk Prediction Engine</h1>
      <div className="dashboard">
        <div className="dashboard-left">
          <CohortView patients={patients} onSelect={handleSelect} />
        </div>
        <div className="dashboard-right">
          {selectedPatient ? (
            <PatientDetail patient={selectedPatient} />
          ) : (
            <div className="placeholder">Select a patient to view details.</div>
          )}
        </div>
      </div>
    </div>
  );
}
