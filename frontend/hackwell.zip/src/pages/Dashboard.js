import React from "react";
import CohortView from "../components/CohortView";

function Dashboard() {
  return (
    <div>
      <h2>Cohort Dashboard</h2>
      <CohortView />
    </div>
  );
}

export default Dashboard;
