import React from "react";
import { Link } from "react-router-dom";

function Home() {
  return (
    <div className="card center">
      <h1>AI-Driven Risk Prediction Engine</h1>
      <p>
        Chronic conditions such as diabetes, obesity, and heart failure require continuous monitoring.
        Our AI engine forecasts whether a patient is at risk of deterioration in the next 90 days,
        helping clinicians intervene earlier.
      </p>
      <ul className="list">
        <li>📊 Cohort View: population-level risk scores</li>
        <li>🧑‍⚕️ Patient Detail View: personalized risk & trends</li>
        <li>🔍 Explainability: feature importance & contributing factors</li>
      </ul>
      <Link to="/dashboard" className="btn">Go to Dashboard →</Link>
    </div>
  );
}

export default Home;
