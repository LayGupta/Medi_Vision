import React from "react";
import PatientDetail from "../components/PatientDetail";

function PatientPage() {
  return <PatientDetail />;
}

export default PatientPage;
