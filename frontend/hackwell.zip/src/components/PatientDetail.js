import React, { useState } from "react";
import { predictRisk } from "../services/api";

export default function PatientDetail({ patient }) {
  const [risk, setRisk] = useState(null);

  const handlePredict = async () => {
    const result = await predictRisk(patient.features);
    setRisk(result);
  };

  return (
    <div className="patient-detail">
      <h2>Patient Detail View</h2>
      <h3>{patient.name}</h3>
      <p><strong>Last Check-in:</strong> {patient.last_checkin}</p>
      <pre>{JSON.stringify(patient.features, null, 2)}</pre>

      <button onClick={handlePredict}>Predict Risk</button>

      {risk && (
        <div className="risk-box">
          <p>
            <strong>Risk Score:</strong> {risk.risk_score}
          </p>
          <p>
            <strong>Category:</strong> {risk.risk_category}
          </p>
        </div>
      )}
    </div>
  );
}
