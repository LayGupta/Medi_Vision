import React from "react";

export default function FeatureImportance({ importance }) {
  if (!importance) return <div>No feature importance available.</div>;

  const entries = Object.entries(importance);
  const maxVal = Math.max(...entries.map(([, v]) => Number(v) || 0)) || 1;

  return (
    <div>
      {entries.map(([name, val]) => {
        const safeVal = Number(val) || 0;
        return (
          <div key={name} className="bar-row">
            <span className="bar-label">{name}</span>
            <div className="bar-track">
              <div
                className="bar-fill"
                style={{ width: `${(100 * safeVal) / maxVal}%` }}
              />
            </div>
            <span className="bar-value">{safeVal.toFixed(2)}</span>
          </div>
        );
      })}
    </div>
  );
}
