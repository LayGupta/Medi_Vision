import React from "react";

export default function RiskChart({ points }) {
  if (!Array.isArray(points) || !points.length) {
    return <div className="placeholder">No trend data.</div>;
  }

  const width = 600;
  const height = 220;
  const padding = 30;

  const xs = points.map((p) => Number(p.x));
  const ys = points.map((p) => Number(p.y));

  const xMin = Math.min(...xs);
  const xMax = Math.max(...xs);
  const yMin = Math.min(...ys);
  const yMax = Math.max(...ys);

  const xScale = (x) =>
    padding +
    ((x - xMin) / (xMax - xMin || 1)) * (width - 2 * padding);

  const yScale = (y) =>
    height -
    padding -
    ((y - yMin) / (yMax - yMin || 1)) * (height - 2 * padding);

  const d = points
    .map((p, i) => `${i ? "L" : "M"} ${xScale(p.x)} ${yScale(p.y)}`)
    .join(" ");

  return (
    <svg width={width} height={height} className="chart">
      <path d={d} fill="none" stroke="steelblue" strokeWidth="2" />
    </svg>
  );
}
